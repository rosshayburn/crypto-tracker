// CryptoTrack service worker — caches the app shell so it installs cleanly
// and opens instantly, but always lets live price/exchange requests hit the network.
var CACHE_NAME = 'cryptotrack-v1';
var APP_SHELL = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){ return cache.addAll(APP_SHELL); })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(e){
  e.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(keys.filter(function(k){return k!==CACHE_NAME;}).map(function(k){return caches.delete(k);}));
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', function(e){
  var url = e.request.url;
  // Never cache live data — prices, rates, and the Binance/CoinGecko APIs must always be fresh
  if(url.indexOf('binance.com') !== -1 || url.indexOf('coingecko.com') !== -1 || e.request.method !== 'GET'){
    return;
  }
  // App shell: cache-first, falling back to network
  e.respondWith(
    caches.match(e.request).then(function(cached){
      return cached || fetch(e.request);
    })
  );
});
